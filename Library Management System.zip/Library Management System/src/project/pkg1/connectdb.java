/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Shashi kant
 */
public class connectdb {
    public static Connection connectdbstu(){
            Connection con = null;
            String host = "jdbc:derby://localhost:1527/database";
            String login = "root";
            String pass = "root";
        try {    
            con = DriverManager.getConnection(host,login,pass);
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(connectdb.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
}
}
