/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg1;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Shashi Kant
 */
public class Mail {
    private static Session Session;
    
    public static void sendmail(String recipient , String msubject , String mtext) throws Exception{
        System.out.println("Getting connection to send Email");
        Properties Properties = new Properties();
        
        Properties.put("mail.smtp.auth","true");
        Properties.put("mail.smtp.starttls.enable","true");
        Properties.put("mail.smtp.host","smtp.gmail.com");
        Properties.put("mail.smtp.port","587");
        
        String myEmail = "******@gmail.com";
        String password = "*********";
        
        Session session = Session.getInstance(Properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myEmail, password);
            }
        });
        
        Message message = prepareMessage(session , myEmail , recipient , msubject , mtext);
        Transport.send(message);
        System.out.println("Email sent successfully");
    }
    
    private static Message prepareMessage(Session session, String myEmail, String recipient, String msubject, String mtext) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(myEmail));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            message.setSubject(msubject);
            message.setText(mtext);
            return message;
        } catch (MessagingException ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
